clc;clear all;close all;

% global movie
movie = [];

% test_sources_jansenRit
cortex = export(gifti('cortex_20484.surf.gii'), 'ft');
FV.vertices = cortex.pnt;
FV.faces = cortex.tri;
disp('refine patch ...');
FV = refinepatch(FV);
TR = TriRep(FV.faces, FV.vertices);
E = edges(TR);
ED = [E sqrt(sum((TR.X(E(:,1),:) - TR.X(E(:,2),:)).^2, 2))];
ED = [ED; [ED(:,2) ED(:,1) ED(:,3)]];
ED = sortrows(ED);
N = size(TR.X,1);
% Place connections with nearby micro-columns
clear E TR
disp('Long range connectivity ...');
ctte = 30;
constdist = 10;
tic; [PathExc, itargetExc] = mex_Dijkstra_BHeap(ED, N, constdist); toc
if exist('PathExc', 'var')
    ii = cell2mat(itargetExc);
    jj = cell2mat(PathExc);
    jj = jj(:,1);
end
eucdist = sqrt(sum((FV.vertices(ii,:) - FV.vertices(jj,:)).^2, 2));
flag = (eucdist <= 7);
ww = normpdf(eucdist(flag),0,3);
S = sparse(ii(flag), jj(flag), ww, N, N);
ConnLR = (1*ctte)*S';
clear itargetExc PathExc S

%% Spikes simulation
disp('NMass dynamic simulation ...');
% parameters and model function
a = 100; b = 50;    % 1/sec
v0 = 6;             % mV
vmax = 5;           % 1/sec, vmax = 2*e0
r = 0.56;           % 1/mV
A = 3.25*a;         % mV/sec
B = 22*b;           % mV/sec
% B = 17.6*b;         % mV/sec
% connectivity strengts
c = 128;
% c = 108;
c1 = c;
c2 = 0.8*c;
c3 = 0.25*c;
c4 = c3;
T = 0.5; % seconds
tau = 1e-3; % 1 ms
p0 = 120; p1 = 320; % discharges per second in range [p0, p1]: Jansen
rng('default');
np = round(T/tau); % number of simulation steps
yheun = zeros(N,np);
ystep = zeros(6,N);
for it = 1:np
    if (mod(it,100)==0), disp(it); end
    pyy = unifrnd(p0, p1, 1, N) + ystep(1,:)*ConnLR;
    F1deriv = [ystep(4:6,:); ...
        A*vmax*sigmf(ystep(2,:)-ystep(3,:), [r v0]) - 2*a*ystep(4,:) - a^2*ystep(1,:); ...
        A*(pyy + c2*vmax*sigmf(c1*ystep(1,:), [r v0])) - 2*a*ystep(5,:) - a^2*ystep(2,:); ...
        B*c4*vmax*sigmf(c3*ystep(1,:), [r v0]) - 2*b*ystep(6,:) - b^2*ystep(3,:)];
    yy = ystep + tau*F1deriv;
    F2deriv = [yy(4:6,:); ...
        A*vmax*sigmf(yy(2,:)-yy(3,:), [r v0]) - 2*a*yy(4,:) - a^2*yy(1,:); ...
        A*(pyy + c2*vmax*sigmf(c1*yy(1,:), [r v0])) - 2*a*yy(5,:) - a^2*yy(2,:); ...
        B*c4*vmax*sigmf(c3*yy(1,:), [r v0]) - 2*b*yy(6,:) - b^2*yy(3,:)];
    ystep = ystep + 0.5*tau*(F1deriv+F2deriv);
    yheun(:,it) = ystep(2,:) - ystep(3,:);
end

%% NMass dynamic in source space
figure, set(gcf, 'Color', [1 1 1], 'NumberTitle', 'off');
for it = 1:5:np
    cla;
    patch('faces', FV.faces, 'vertices', FV.vertices, 'CData', yheun(:,it), ...
        'EdgeColor', 'none', 'FaceColor', 'interp');
    axis image;
    if (mod(it,20) == 0), set(gcf, 'name', sprintf('time = %d ms', it)); end 
    title([sprintf('time = %d ms', it)])
    drawnow();
    view([-44,14]);
%     axis off
    movie = [movie;getframe(gcf)];
    pause(0.05);
end
           

ask = input('save movie? yes=1 : ');
name = 'output1';
if ask==1
    %% Making movie in the current folder
    F=[];
    repeats = 1; % # of times to repeat each frame
    for count = 1:length(movie)
        tmp = movie(count);
        for k =1:repeats
            F=[F;tmp];
        end
    end
    movie2avi(F,[name,'.avi'], 'compression', 'None');
end

% patch('faces', FV.faces, 'vertices', FV.vertices, 'FaceColor', [0 0 1], ...
% 'EdgeColor', [0 0 0]);
% xlabel('x'); ylabel('y'); zlabel('z')